<?php

return [
    'site_title' => 'Asset Management',
];
