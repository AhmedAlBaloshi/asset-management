<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('cruds.assetsHistory.title_singular')); ?> <?php echo e(trans('global.list')); ?>

    </div>

    <div class="card-body">
        <div class="table-responsive">
            <table class=" table table-bordered table-striped table-hover datatable datatable-AssetsHistory">
                <thead>
                    <tr>
                        <th width="10"></th>
                        <th><?php echo e(trans('global.code')); ?></th>
                        <th><?php echo e(trans('global.asset')); ?></th>
                        <th><?php echo e(trans('global.location_name')); ?></th>
                        <th><?php echo e(trans('global.quantity')); ?></th>
                        <th><?php echo e(trans('global.created_at')); ?></th>
                        <th><?php echo e(trans('global.updated_at')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $assetLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $assetLocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-entry-id="<?php echo e($assetLocation->id); ?>">
                            <td></td>
                            <td><?php echo e($assetLocation->code ?? ''); ?></td>
                            <td><?php echo e($assetLocation->name ?? ''); ?></td>
                            <td><?php echo e($assetLocation->location_name ?? ''); ?></td>
                            <td><?php echo e($assetLocation->quantity ?? ''); ?></td>
                            <td><?php echo e($assetLocation->created_at ?? ''); ?></td>
                            <td><?php echo e($assetLocation->updated_at ?? ''); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script>
$(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
  
  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-AssetsHistory:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asset\resources\views/admin/assetsHistories/index.blade.php ENDPATH**/ ?>