<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                Asset by Specific Location
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route("admin.accounting.show-specific-location")); ?>" enctype="multipart/form-data" target="_blank">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="location">Location</label>
                        <select name="location" class="form-control select2" id="location">
                            <?php $__currentLoopData = $list_location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($loc->id); ?>"><?php echo e($loc->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-sm btn-success" value="Show" />
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/husen/Documents/RunDev/Products/OwnProduct/Asset Management/source code/resources/views/admin/accounting/asset_by_specific_location.blade.php ENDPATH**/ ?>