<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.company.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.companies.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="company_name"><?php echo e(trans('cruds.company.fields.company_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('company_name') ? 'is-invalid' : ''); ?>" type="text" name="company_name" id="company_name" value="<?php echo e(old('company_name', '')); ?>">
                <?php if($errors->has('company_name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('company_name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.company.fields.company_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="address"><?php echo e(trans('cruds.company.fields.address')); ?></label>
                <textarea class="form-control ckeditor <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" name="address" id="address"><?php echo old('address'); ?></textarea>
                <?php if($errors->has('address')): ?>
                    <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.company.fields.address_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="city"><?php echo e(trans('cruds.company.fields.city')); ?></label>
                <input class="form-control <?php echo e($errors->has('city') ? 'is-invalid' : ''); ?>" type="text" name="city" id="city" value="<?php echo e(old('city', '')); ?>">
                <?php if($errors->has('city')): ?>
                    <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.company.fields.city_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="phone"><?php echo e(trans('cruds.company.fields.phone')); ?></label>
                <input class="form-control <?php echo e($errors->has('phone') ? 'is-invalid' : ''); ?>" type="text" name="phone" id="phone" value="<?php echo e(old('phone', '')); ?>">
                <?php if($errors->has('phone')): ?>
                    <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.company.fields.phone_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="fax"><?php echo e(trans('cruds.company.fields.fax')); ?></label>
                <input class="form-control <?php echo e($errors->has('fax') ? 'is-invalid' : ''); ?>" type="text" name="fax" id="fax" value="<?php echo e(old('fax', '')); ?>">
                <?php if($errors->has('fax')): ?>
                    <span class="text-danger"><?php echo e($errors->first('fax')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.company.fields.fax_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="postal"><?php echo e(trans('cruds.company.fields.postal')); ?></label>
                <input class="form-control <?php echo e($errors->has('postal') ? 'is-invalid' : ''); ?>" type="text" name="postal" id="postal" value="<?php echo e(old('postal', '')); ?>">
                <?php if($errors->has('postal')): ?>
                    <span class="text-danger"><?php echo e($errors->first('postal')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.company.fields.postal_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="email"><?php echo e(trans('cruds.company.fields.email')); ?></label>
                <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="text" name="email" id="email" value="<?php echo e(old('email', '')); ?>">
                <?php if($errors->has('email')): ?>
                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.company.fields.email_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="website"><?php echo e(trans('cruds.company.fields.website')); ?></label>
                <input class="form-control <?php echo e($errors->has('website') ? 'is-invalid' : ''); ?>" type="text" name="website" id="website" value="<?php echo e(old('website', '')); ?>">
                <?php if($errors->has('website')): ?>
                    <span class="text-danger"><?php echo e($errors->first('website')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.company.fields.website_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="owner_name"><?php echo e(trans('cruds.company.fields.owner_name')); ?></label>
                <input class="form-control <?php echo e($errors->has('owner_name') ? 'is-invalid' : ''); ?>" type="text" name="owner_name" id="owner_name" value="<?php echo e(old('owner_name', '')); ?>">
                <?php if($errors->has('owner_name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('owner_name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.company.fields.owner_name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="user"><?php echo e(trans('cruds.company.fields.user')); ?></label>
                <input class="form-control <?php echo e($errors->has('user') ? 'is-invalid' : ''); ?>" type="text" name="user" id="user" value="<?php echo e(old('user', '')); ?>">
                <?php if($errors->has('user')): ?>
                    <span class="text-danger"><?php echo e($errors->first('user')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.company.fields.user_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '/admin/companies/ckmedia', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($company->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/husen/Documents/RunDev/Products/OwnProduct/Asset Management/source code/resources/views/admin/companies/create.blade.php ENDPATH**/ ?>