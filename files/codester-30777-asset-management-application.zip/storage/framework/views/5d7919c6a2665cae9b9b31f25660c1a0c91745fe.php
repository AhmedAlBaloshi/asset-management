<aside class="main-sidebar sidebar-dark-primary elevation-4" style="min-height: 917px;">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <span class="brand-text font-weight-light"><?php echo e(trans('panel.site_title')); ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route("admin.home")); ?>">
                        <i class="fas fa-fw fa-tachometer-alt nav-icon">
                        </i>
                        <p>
                            <?php echo e(trans('global.dashboard')); ?>

                        </p>
                    </a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('supplier_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.suppliers.index")); ?>" class="nav-link <?php echo e(request()->is("admin/suppliers") || request()->is("admin/suppliers/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-luggage-cart">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.supplier.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('license_management_access')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.license-managements.index")); ?>" class="nav-link <?php echo e(request()->is("admin/license-managements") || request()->is("admin/license-managements/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-id-card">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.licenseManagement.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/asset-categories*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/brands*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/asset-locations*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/asset-statuses*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/assets*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/assets-histories*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw nav-icon fas fa-book">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.assetManagement.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_category_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.asset-categories.index")); ?>" class="nav-link <?php echo e(request()->is("admin/asset-categories") || request()->is("admin/asset-categories/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-tags">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.assetCategory.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('brand_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.brands.index")); ?>" class="nav-link <?php echo e(request()->is("admin/brands") || request()->is("admin/brands/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-tags">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.brand.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_location_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.asset-locations.index")); ?>" class="nav-link <?php echo e(request()->is("admin/asset-locations") || request()->is("admin/asset-locations/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-map-marker">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.assetLocation.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_status_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.asset-statuses.index")); ?>" class="nav-link <?php echo e(request()->is("admin/asset-statuses") || request()->is("admin/asset-statuses/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-server">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.assetStatus.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('asset_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.assets.index")); ?>" class="nav-link <?php echo e(request()->is("admin/assets") || request()->is("admin/assets/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-book">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.asset.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assets_history_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.assets-histories.index")); ?>" class="nav-link <?php echo e(request()->is("admin/assets-histories") || request()->is("admin/assets-histories/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-th-list">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.assetsHistory.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/companies*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/permissions*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/users*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/teams*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle" href="#">
                            <i class="fa-fw nav-icon fas fa-users">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.userManagement.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('company_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.companies.index")); ?>" class="nav-link <?php echo e(request()->is("admin/companies") || request()->is("admin/companies/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-building">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.company.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.permissions.index")); ?>" class="nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-unlock-alt">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.permission.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.roles.index")); ?>" class="nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-briefcase">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.role.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.users.index")); ?>" class="nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-user">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.user.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('team_access')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.teams.index")); ?>" class="nav-link <?php echo e(request()->is("admin/teams") || request()->is("admin/teams/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-users">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.team.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php ($unread = \App\Models\QaTopic::unreadCount()); ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.messenger.index")); ?>" class="<?php echo e(request()->is("admin/messenger") || request()->is("admin/messenger/*") ? "active" : ""); ?> nav-link">
                            <i class="fa-fw fa fa-envelope nav-icon">

                            </i>
                            <p><?php echo e(trans('global.messages')); ?></p>
                            <?php if($unread > 0): ?>
                                <strong>( <?php echo e($unread); ?> )</strong>
                            <?php endif; ?>

                        </a>
                    </li>
                    <?php if(\Illuminate\Support\Facades\Schema::hasColumn('teams', 'owner_id') && \App\Models\Team::where('owner_id', auth()->user()->id)->exists()): ?>
                        <li class="nav-item">
                            <a class="<?php echo e(request()->is("admin/team-members") || request()->is("admin/team-members/*") ? "active" : ""); ?> nav-link" href="<?php echo e(route("admin.team-members.index")); ?>">
                                <i class="fa-fw fa fa-users nav-icon">
                                </i>
                                <p>
                                    <?php echo e(trans("global.team-members")); ?>

                                </p>
                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                                    <i class="fa-fw fas fa-key nav-icon">
                                    </i>
                                    <p>
                                        <?php echo e(trans('global.change_password')); ?>

                                    </p>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                            <p>
                                <i class="fas fa-fw fa-sign-out-alt nav-icon">

                                </i>
                                <p><?php echo e(trans('global.logout')); ?></p>
                            </p>
                        </a>
                    </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH /home/husen/Documents/RunDev/Products/Asset17/source code/resources/views/partials/menu.blade.php ENDPATH**/ ?>