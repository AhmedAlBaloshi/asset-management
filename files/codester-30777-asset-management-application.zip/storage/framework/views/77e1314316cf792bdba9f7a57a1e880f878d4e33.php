<html>
    <head>
        <title>Asset by Specific Location</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css" integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
    </head>
    <body onload="window.print()">
        <div class="container">
            <div class="row">
                <div class="col-md-12" align="center">
                    <h3><?php echo e($company->company_name ?? ''); ?></h3>
                    <strong>Asset by Specific Location</strong>
                    <hr/>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>                                    
                                    <th><?php echo e(trans('global.code')); ?></th>
                                    <th><?php echo e(trans('global.name')); ?></th>
                                    <th><?php echo e(trans('global.quantity')); ?></th>
                                    <th><?php echo e(trans('global.unit_price')); ?></th>
                                    <th><?php echo e(trans('global.total')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $sumTotalOnDepartment = 0; ?>
                                    <tr>
                                        <td colspan="5"><?php echo e(trans('global.location')); ?> : <strong><?php echo e($location_name->name); ?></strong></td>
                                    </tr>
                                    <?php $__currentLoopData = $assets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($asset->code); ?></td>
                                            <td><?php echo e($asset->name); ?></td>
                                            <td align="right"><?php echo e(number_format($asset->quantity,2)); ?></td>
                                            <td align="right"><?php echo e(number_format($asset->unit_price,2)); ?></td>
                                            <td align="right"><?php $sumTotal=$asset->quantity * $asset->unit_price; echo number_format($sumTotal,2); ?></td>
                                        </tr>
                                        <?php $sumTotalOnDepartment+=$sumTotal; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $getTotalAssetsByLocation = \App\Http\Controllers\Admin\AccountingController::getTotalAssetsByLocation($location_id);
                                    ?>
                                    <tr>
                                        <td colspan="4" align="right"><strong>Total</strong></td>
                                        <td align="right"><strong><?php echo number_format($sumTotalOnDepartment,2); ?></strong></td>
                                    </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html><?php /**PATH /home/husen/Documents/RunDev/Products/OwnProduct/Asset Management/source code/resources/views/admin/accounting/show_specific_location.blade.php ENDPATH**/ ?>