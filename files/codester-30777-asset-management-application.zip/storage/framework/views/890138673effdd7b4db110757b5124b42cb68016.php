<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.asset.title')); ?>

            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <?php if($asset->photo): ?>
                    <a href="<?php echo e($asset->photo->getUrl()); ?>" target="_blank" style="display: inline-block">
                        <img src="<?php echo e($asset->photo->getUrl()); ?>" width="200px">
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <tbody>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.code')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->code); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.serial_number')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->serial_number); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.license')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->license->license ?? ''); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.name')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->name); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.brand')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->brand->name ?? ''); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.category')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->category->name ?? ''); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>        
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <tbody>                        
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.supplier')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->supplier->name ?? ''); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.date_of_purchase')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->date_of_purchase); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.quantity')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->quantity); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.unit_price')); ?>

                            </th>
                            <td>
                                <?php echo e(number_format($asset->unit_price,2)); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.warranty_period')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->warranty_period); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.depreciation')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->depreciation); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.status')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->status->name ?? ''); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.location')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->location->name ?? ''); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.notes')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->notes); ?>

                            </td>
                        </tr>
                        <tr>
                            <th>
                                <?php echo e(trans('cruds.asset.fields.assigned_to')); ?>

                            </th>
                            <td>
                                <?php echo e($asset->assigned_to->name ?? ''); ?>

                            </td>
                        </tr>
                        <tr>
                            <td align="right" colspan="2">
                                <div class="form-group">
                                    <a class="btn btn-default" href="<?php echo e(route('admin.assets.index')); ?>">
                                        <?php echo e(trans('global.back_to_list')); ?>

                                    </a>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!--
<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.asset.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.assets.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.photo')); ?>

                        </th>
                        <td>
                            <?php if($asset->photo): ?>
                                <a href="<?php echo e($asset->photo->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($asset->photo->getUrl('thumb')); ?>">
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.code')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->code); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.serial_number')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->serial_number); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.license')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->license->license ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.brand')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->brand->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.category')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->category->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.supplier')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->supplier->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.date_of_purchase')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->date_of_purchase); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.quantity')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->quantity); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.unit_price')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->unit_price); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.total')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->total); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.warranty_period')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->warranty_period); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.depreciation')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->depreciation); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.status')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->status->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.location')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->location->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.notes')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->notes); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.asset.fields.assigned_to')); ?>

                        </th>
                        <td>
                            <?php echo e($asset->assigned_to->name ?? ''); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.assets.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>
-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/husen/Documents/RunDev/Products/asset17/resources/views/admin/assets/show.blade.php ENDPATH**/ ?>