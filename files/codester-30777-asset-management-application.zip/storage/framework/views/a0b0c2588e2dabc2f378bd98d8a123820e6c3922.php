<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">Accounting</div>
</div>

<div class="row">
    <div class="col-md-2">
        <div class="card">
            <div class="card-body" align="center">
                <img src="<?php echo e(URL::to('/')); ?>/icons/report.png" width="48px" /><br/>                
            </div>
            <div class="card-footer" align="center">
                <a href="<?php echo e(route("admin.accounting.asset-by-specific-location")); ?>" target="_blank">Asset by Value</a>
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="card">
            <div class="card-body" align="center">
                <img src="<?php echo e(URL::to('/')); ?>/icons/location.gif" width="48px" /><br/>                
            </div>
            <div class="card-footer" align="center">
                <a href="<?php echo e(route("admin.accounting.asset-by-location")); ?>" target="_blank">Asset by Location</a>
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="card">
            <div class="card-body" align="center">
                <img src="<?php echo e(URL::to('/')); ?>/icons/specific-location.png" width="48px" /><br/>                
            </div>
            <div class="card-footer" align="center">
                <a href="<?php echo e(route("admin.accounting.asset-by-specific-location")); ?>">Specific Location</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/husen/Documents/RunDev/Products/OwnProduct/Asset Management/source code/resources/views/admin/accounting/index.blade.php ENDPATH**/ ?>