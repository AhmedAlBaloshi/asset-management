<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route("admin.assets.store")); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <input type="hidden" name="location_id" id="location_id" value="1" />
    </div>
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">                    
                    <div class="form-group">
                        <label class="required" for="code"><?php echo e(trans('cruds.asset.fields.code')); ?></label>
                        <input class="form-control <?php echo e($errors->has('code') ? 'is-invalid' : ''); ?>" type="text" name="code" id="code" value="<?php echo e(old('code', '')); ?>" required>
                        <?php if($errors->has('code')): ?>
                            <span class="text-danger"><?php echo e($errors->first('code')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.code_helper')); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="serial_number"><?php echo e(trans('cruds.asset.fields.serial_number')); ?></label>
                        <input class="form-control <?php echo e($errors->has('serial_number') ? 'is-invalid' : ''); ?>" type="text" name="serial_number" id="serial_number" value="<?php echo e(old('serial_number', '')); ?>">
                        <?php if($errors->has('serial_number')): ?>
                            <span class="text-danger"><?php echo e($errors->first('serial_number')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.serial_number_helper')); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="license_id"><?php echo e(trans('cruds.asset.fields.license')); ?></label>
                        <select class="form-control select2 <?php echo e($errors->has('license') ? 'is-invalid' : ''); ?>" name="license_id" id="license_id">
                            <?php $__currentLoopData = $licenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('license_id') == $id ? 'selected' : ''); ?>><?php echo e($license); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('license')): ?>
                            <span class="text-danger"><?php echo e($errors->first('license')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.license_helper')); ?></span>
                    </div>
                    <div class="form-group">
                        <label class="required" for="name"><?php echo e(trans('cruds.asset.fields.name')); ?></label>
                        <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                        <?php if($errors->has('name')): ?>
                            <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.name_helper')); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="brand_id"><?php echo e(trans('cruds.asset.fields.brand')); ?></label>
                        <select class="form-control select2 <?php echo e($errors->has('brand') ? 'is-invalid' : ''); ?>" name="brand_id" id="brand_id">
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('brand_id') == $id ? 'selected' : ''); ?>><?php echo e($brand); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('brand')): ?>
                            <span class="text-danger"><?php echo e($errors->first('brand')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.brand_helper')); ?></span>
                    </div>
                    <div class="form-group">
                        <label class="required" for="category_id"><?php echo e(trans('cruds.asset.fields.category')); ?></label>
                        <select class="form-control select2 <?php echo e($errors->has('category') ? 'is-invalid' : ''); ?>" name="category_id" id="category_id" required>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('category_id') == $id ? 'selected' : ''); ?>><?php echo e($category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('category')): ?>
                            <span class="text-danger"><?php echo e($errors->first('category')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.category_helper')); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="supplier_id"><?php echo e(trans('cruds.asset.fields.supplier')); ?></label>
                        <select class="form-control select2 <?php echo e($errors->has('supplier') ? 'is-invalid' : ''); ?>" name="supplier_id" id="supplier_id">
                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('supplier_id') == $id ? 'selected' : ''); ?>><?php echo e($supplier); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('supplier')): ?>
                            <span class="text-danger"><?php echo e($errors->first('supplier')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.supplier_helper')); ?></span>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label class="required" for="status_id"><?php echo e(trans('cruds.asset.fields.status')); ?></label>
                        <select class="form-control select2 <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status_id" id="status_id" required>
                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('status_id') == $id ? 'selected' : ''); ?>><?php echo e($status); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('status')): ?>
                            <span class="text-danger"><?php echo e($errors->first('status')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.status_helper')); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="notes"><?php echo e(trans('cruds.asset.fields.notes')); ?></label>
                        <textarea class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" name="notes" id="notes"><?php echo e(old('notes')); ?></textarea>
                        <?php if($errors->has('notes')): ?>
                            <span class="text-danger"><?php echo e($errors->first('notes')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.notes_helper')); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="assigned_to_id"><?php echo e(trans('cruds.asset.fields.assigned_to')); ?></label>
                        <select class="form-control select2 <?php echo e($errors->has('assigned_to') ? 'is-invalid' : ''); ?>" name="assigned_to_id" id="assigned_to_id">
                            <?php $__currentLoopData = $assigned_tos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $assigned_to): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>" <?php echo e(old('assigned_to_id') == $id ? 'selected' : ''); ?>><?php echo e($assigned_to); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('assigned_to')): ?>
                            <span class="text-danger"><?php echo e($errors->first('assigned_to')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.assigned_to_helper')); ?></span>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="photo"><?php echo e(trans('cruds.asset.fields.photo')); ?></label>
                        <div class="needsclick dropzone <?php echo e($errors->has('photo') ? 'is-invalid' : ''); ?>" id="photo-dropzone">
                        </div>
                        <?php if($errors->has('photo')): ?>
                            <span class="text-danger"><?php echo e($errors->first('photo')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.photo_helper')); ?></span>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="date_of_purchase"><?php echo e(trans('cruds.asset.fields.date_of_purchase')); ?></label>
                        <input class="form-control date <?php echo e($errors->has('date_of_purchase') ? 'is-invalid' : ''); ?>" type="text" name="date_of_purchase" id="date_of_purchase" value="<?php echo e(old('date_of_purchase')); ?>">
                        <?php if($errors->has('date_of_purchase')): ?>
                            <span class="text-danger"><?php echo e($errors->first('date_of_purchase')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.date_of_purchase_helper')); ?></span>
                    </div>
                    <div class="form-group">
                        <label class="required" for="quantity"><?php echo e(trans('cruds.asset.fields.quantity')); ?></label>
                        <input class="form-control <?php echo e($errors->has('quantity') ? 'is-invalid' : ''); ?>" type="number" name="quantity" id="quantity" value="<?php echo e(old('quantity', '')); ?>" step="0.01" required>
                        <?php if($errors->has('quantity')): ?>
                            <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.quantity_helper')); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="unit_price"><?php echo e(trans('cruds.asset.fields.unit_price')); ?></label>
                        <input class="form-control <?php echo e($errors->has('unit_price') ? 'is-invalid' : ''); ?>" type="number" name="unit_price" id="unit_price" value="<?php echo e(old('unit_price', '')); ?>" step="0.01">
                        <?php if($errors->has('unit_price')): ?>
                            <span class="text-danger"><?php echo e($errors->first('unit_price')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.unit_price_helper')); ?></span>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="warranty_period"><?php echo e(trans('cruds.asset.fields.warranty_period')); ?></label>
                        <input class="form-control <?php echo e($errors->has('warranty_period') ? 'is-invalid' : ''); ?>" type="text" name="warranty_period" id="warranty_period" value="<?php echo e(old('warranty_period', '')); ?>">
                        <?php if($errors->has('warranty_period')): ?>
                            <span class="text-danger"><?php echo e($errors->first('warranty_period')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.warranty_period_helper')); ?></span>
                    </div>
                    <div class="form-group">
                        <label for="depreciation"><?php echo e(trans('cruds.asset.fields.depreciation')); ?></label>
                        <input class="form-control <?php echo e($errors->has('depreciation') ? 'is-invalid' : ''); ?>" type="text" name="depreciation" id="depreciation" value="<?php echo e(old('depreciation', '')); ?>">
                        <?php if($errors->has('depreciation')): ?>
                            <span class="text-danger"><?php echo e($errors->first('depreciation')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.asset.fields.depreciation_helper')); ?></span>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <button class="btn btn-danger" type="submit">
                            <?php echo e(trans('global.save')); ?>

                        </button>
                    </div>
                </div>
            </div>            
        </div>
    </div>
</form>

<!--
<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.asset.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.assets.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="photo"><?php echo e(trans('cruds.asset.fields.photo')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('photo') ? 'is-invalid' : ''); ?>" id="photo-dropzone">
                </div>
                <?php if($errors->has('photo')): ?>
                    <span class="text-danger"><?php echo e($errors->first('photo')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.photo_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="code"><?php echo e(trans('cruds.asset.fields.code')); ?></label>
                <input class="form-control <?php echo e($errors->has('code') ? 'is-invalid' : ''); ?>" type="text" name="code" id="code" value="<?php echo e(old('code', '')); ?>" required>
                <?php if($errors->has('code')): ?>
                    <span class="text-danger"><?php echo e($errors->first('code')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.code_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="serial_number"><?php echo e(trans('cruds.asset.fields.serial_number')); ?></label>
                <input class="form-control <?php echo e($errors->has('serial_number') ? 'is-invalid' : ''); ?>" type="text" name="serial_number" id="serial_number" value="<?php echo e(old('serial_number', '')); ?>">
                <?php if($errors->has('serial_number')): ?>
                    <span class="text-danger"><?php echo e($errors->first('serial_number')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.serial_number_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="license_id"><?php echo e(trans('cruds.asset.fields.license')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('license') ? 'is-invalid' : ''); ?>" name="license_id" id="license_id">
                    <?php $__currentLoopData = $licenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $license): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('license_id') == $id ? 'selected' : ''); ?>><?php echo e($license); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('license')): ?>
                    <span class="text-danger"><?php echo e($errors->first('license')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.license_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.asset.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="brand_id"><?php echo e(trans('cruds.asset.fields.brand')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('brand') ? 'is-invalid' : ''); ?>" name="brand_id" id="brand_id">
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('brand_id') == $id ? 'selected' : ''); ?>><?php echo e($brand); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('brand')): ?>
                    <span class="text-danger"><?php echo e($errors->first('brand')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.brand_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="category_id"><?php echo e(trans('cruds.asset.fields.category')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('category') ? 'is-invalid' : ''); ?>" name="category_id" id="category_id" required>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('category_id') == $id ? 'selected' : ''); ?>><?php echo e($category); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('category')): ?>
                    <span class="text-danger"><?php echo e($errors->first('category')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.category_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="supplier_id"><?php echo e(trans('cruds.asset.fields.supplier')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('supplier') ? 'is-invalid' : ''); ?>" name="supplier_id" id="supplier_id">
                    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('supplier_id') == $id ? 'selected' : ''); ?>><?php echo e($supplier); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('supplier')): ?>
                    <span class="text-danger"><?php echo e($errors->first('supplier')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.supplier_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="date_of_purchase"><?php echo e(trans('cruds.asset.fields.date_of_purchase')); ?></label>
                <input class="form-control date <?php echo e($errors->has('date_of_purchase') ? 'is-invalid' : ''); ?>" type="text" name="date_of_purchase" id="date_of_purchase" value="<?php echo e(old('date_of_purchase')); ?>">
                <?php if($errors->has('date_of_purchase')): ?>
                    <span class="text-danger"><?php echo e($errors->first('date_of_purchase')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.date_of_purchase_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="quantity"><?php echo e(trans('cruds.asset.fields.quantity')); ?></label>
                <input class="form-control <?php echo e($errors->has('quantity') ? 'is-invalid' : ''); ?>" type="number" name="quantity" id="quantity" value="<?php echo e(old('quantity', '')); ?>" step="0.01" required>
                <?php if($errors->has('quantity')): ?>
                    <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.quantity_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="unit_price"><?php echo e(trans('cruds.asset.fields.unit_price')); ?></label>
                <input class="form-control <?php echo e($errors->has('unit_price') ? 'is-invalid' : ''); ?>" type="number" name="unit_price" id="unit_price" value="<?php echo e(old('unit_price', '')); ?>" step="0.01">
                <?php if($errors->has('unit_price')): ?>
                    <span class="text-danger"><?php echo e($errors->first('unit_price')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.unit_price_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="total"><?php echo e(trans('cruds.asset.fields.total')); ?></label>
                <input class="form-control <?php echo e($errors->has('total') ? 'is-invalid' : ''); ?>" type="number" name="total" id="total" value="<?php echo e(old('total', '')); ?>" step="0.01">
                <?php if($errors->has('total')): ?>
                    <span class="text-danger"><?php echo e($errors->first('total')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.total_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="warranty_period"><?php echo e(trans('cruds.asset.fields.warranty_period')); ?></label>
                <input class="form-control <?php echo e($errors->has('warranty_period') ? 'is-invalid' : ''); ?>" type="text" name="warranty_period" id="warranty_period" value="<?php echo e(old('warranty_period', '')); ?>">
                <?php if($errors->has('warranty_period')): ?>
                    <span class="text-danger"><?php echo e($errors->first('warranty_period')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.warranty_period_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="depreciation"><?php echo e(trans('cruds.asset.fields.depreciation')); ?></label>
                <input class="form-control <?php echo e($errors->has('depreciation') ? 'is-invalid' : ''); ?>" type="text" name="depreciation" id="depreciation" value="<?php echo e(old('depreciation', '')); ?>">
                <?php if($errors->has('depreciation')): ?>
                    <span class="text-danger"><?php echo e($errors->first('depreciation')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.depreciation_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="status_id"><?php echo e(trans('cruds.asset.fields.status')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status_id" id="status_id" required>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('status_id') == $id ? 'selected' : ''); ?>><?php echo e($status); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <span class="text-danger"><?php echo e($errors->first('status')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.status_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="location_id"><?php echo e(trans('cruds.asset.fields.location')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('location') ? 'is-invalid' : ''); ?>" name="location_id" id="location_id" required>
                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('location_id') == $id ? 'selected' : ''); ?>><?php echo e($location); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('location')): ?>
                    <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.location_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="notes"><?php echo e(trans('cruds.asset.fields.notes')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" name="notes" id="notes"><?php echo e(old('notes')); ?></textarea>
                <?php if($errors->has('notes')): ?>
                    <span class="text-danger"><?php echo e($errors->first('notes')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.notes_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="assigned_to_id"><?php echo e(trans('cruds.asset.fields.assigned_to')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('assigned_to') ? 'is-invalid' : ''); ?>" name="assigned_to_id" id="assigned_to_id">
                    <?php $__currentLoopData = $assigned_tos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $assigned_to): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('assigned_to_id') == $id ? 'selected' : ''); ?>><?php echo e($assigned_to); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('assigned_to')): ?>
                    <span class="text-danger"><?php echo e($errors->first('assigned_to')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.asset.fields.assigned_to_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
-->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.photoDropzone = {
    url: '<?php echo e(route('admin.assets.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="photo"]').remove()
      $('form').append('<input type="hidden" name="photo" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="photo"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($asset) && $asset->photo): ?>
      var file = <?php echo json_encode($asset->photo); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="photo" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\asset\resources\views/admin/assets/create.blade.php ENDPATH**/ ?>