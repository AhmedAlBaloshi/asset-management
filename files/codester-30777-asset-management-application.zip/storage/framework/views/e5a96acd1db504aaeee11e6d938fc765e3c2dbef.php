<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.licenseManagement.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.licenseManagement.fields.license')); ?>

                        </th>
                        <td>
                            <?php echo e($licenseManagement->license); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.licenseManagement.fields.title')); ?>

                        </th>
                        <td>
                            <?php echo e($licenseManagement->title); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.licenseManagement.fields.description')); ?>

                        </th>
                        <td>
                            <?php echo $licenseManagement->description; ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-success" href="/admin/license-managements/<?php echo e($licenseManagement->id); ?>/edit">
                    <i class="fa fa-edit"></i> 
                    <?php echo e(trans('global.edit')); ?>

                </a>
                <a class="btn btn-default" href="<?php echo e(route('admin.license-managements.index')); ?>">
                    <i class="fa fa-arrow-circle-left"></i> 
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/husen/Documents/RunDev/Products/OwnProduct/Asset Management/source code/resources/views/admin/licenseManagements/show.blade.php ENDPATH**/ ?>