<?php $__env->startSection('content'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('locations_create')): ?>
    <div style="margin-bottom: 10px;" class="row">
        <div class="col-lg-12">
            <a class="btn btn-success" href="<?php echo e(route('admin.assets.create')); ?>">
                <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.asset.title_singular')); ?>

            </a>
        </div>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/husen/Documents/RunDev/Products/OwnProduct/Asset17/source code/resources/views/admin/locations/index.blade.php ENDPATH**/ ?>